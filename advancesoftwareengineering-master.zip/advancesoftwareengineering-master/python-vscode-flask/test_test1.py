def test_mock():
  assert True
